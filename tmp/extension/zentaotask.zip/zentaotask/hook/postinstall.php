<?php
$this->loadModel('setting')->setItem('system.common.global.flow', 'onlyTask');
