<?php
unset($lang->doc->systemLibs['product']);
