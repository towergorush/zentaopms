<?php
unset($lang->project->groups['story']);
