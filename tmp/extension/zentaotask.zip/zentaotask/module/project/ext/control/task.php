<?php
/**
 * The control file of project module of ZenTaoPMS.
 *
 * @copyright   Copyright 2009-2011 青岛易软天创网络科技有限公司 (QingDao Nature Easy Soft Network Technology Co,LTD www.cnezsoft.com)
 * @license     LGPL (http://www.gnu.org/licenses/lgpl.html)
 * @author      Chunsheng Wang <chunsheng@cnezsoft.com>
 * @package     project
 * @version     $Id: control.php 1961 2011-06-30 08:04:02Z wwccss $
 * @link        http://www.zentao.net
 */
include "../../control.php";
class myproject extends project
{
    /**
     * Tasks of a project.
     *
     * @param  int    $projectID
     * @param  string $status
     * @param  string $orderBy
     * @param  int    $recTotal
     * @param  int    $recPerPage
     * @param  int    $pageID
     * @access public
     * @return void
     */
    public function task($projectID = 0, $status = 'byModule', $param = 0, $orderBy = '', $recTotal = 0, $recPerPage = 100, $pageID = 1)
    {
        $this->loadModel('tree');

        /* Set browseType, productID, moduleID and queryID. */
        $browseType = strtolower($status);
        $queryID    = ($browseType == 'bysearch') ? (int)$param : 0;
        $moduleID   = ($status == 'byModule') ? (int)$param : 0;
        $project    = $this->commonAction($projectID);
        $projectID  = $project->id;

        /* Save to session. */
        $uri = $this->app->getURI(true);
        $this->app->session->set('taskList',    $uri);
        $this->app->session->set('storyList',   $uri);
        $this->app->session->set('projectList', $uri);

        /* Process the order by field. */
        if(!$orderBy) $orderBy = $this->cookie->projectTaskOrder ? $this->cookie->projectTaskOrder : 'status,id_desc';
        setcookie('projectTaskOrder', $orderBy, $this->config->cookieLife, $this->config->webRoot);

        /* Header and position. */
        $this->view->title      = $project->name . $this->lang->colon . $this->lang->project->task;
        $this->view->position[] = html::a($this->createLink('project', 'browse', "projectID=$projectID"), $project->name);
        $this->view->position[] = $this->lang->project->task;

        /* Load pager and get tasks. */
        $this->app->loadClass('pager', $static = true);
        $pager = new pager($recTotal, $recPerPage, $pageID);

        $tasks = array();
        if($status == 'byModule')
        {
            $tasks = $this->loadModel('task')->getTasksByModule($projectID, $this->tree->getAllChildID($moduleID), $orderBy, $pager);
        }
        elseif($browseType != "bysearch")
        {
            $status = $status == 'byProject' ? 'all' : $status;
            $tasks = $this->loadModel('task')->getProjectTasks($projectID, $status, $orderBy, $pager);
        }
        else
        {
            if($queryID)
            {
                $query = $this->loadModel('search')->getQuery($queryID);
                if($query)
                {
                    $this->session->set('taskQuery', $query->sql);
                    $this->session->set('taskForm', $query->form);
                }
                else
                {
                    $this->session->set('taskQuery', ' 1 = 1');
                }
            }
            else
            {
                if($this->session->taskQuery == false) $this->session->set('taskQuery', ' 1 = 1');
            }
            /* Limit current project when no project. */
            if(strpos($this->session->taskQuery, "`project` =") === false) $this->session->set('taskQuery', $this->session->taskQuery . " AND `project` = $projectID");
            $taskQuery = str_replace("`project` = 'all'", '1', $this->session->taskQuery); // Search all project.
            $this->session->set('taskQueryCondition', $taskQuery);
            $this->session->set('taskOrderBy', $orderBy);
            $tasks = $this->project->getSearchTasks($taskQuery, $pager, $orderBy);
        }

       /* Build the search form. */
        $this->config->project->search['actionURL'] = $this->createLink('project', 'task', "projectID=$projectID&status=bySearch&param=myQueryID");
        $this->config->project->search['queryID']   = $queryID;
        $this->config->project->search['params']['project']['values'] = array(''=>'', $projectID => $this->projects[$projectID], 'all' => $this->lang->project->allProject);
        $this->config->project->search['params']['module']['values']  = $this->tree->getOptionMenu($projectID, $viewType = 'task', $startModuleID = 0);
        $this->view->searchForm = $this->fetch('search', 'buildForm', $this->config->project->search);

        /* Assign. */
        $this->view->tasks       = $tasks;
        $this->view->summary     = $this->project->summary($tasks);
        $this->view->tabID       = 'task';
        $this->view->pager       = $pager;
        $this->view->recTotal    = $pager->recTotal;
        $this->view->recPerPage  = $pager->recPerPage;
        $this->view->orderBy     = $orderBy;
        $this->view->browseType  = $browseType;
        $this->view->status      = $status;
        $this->view->users       = $this->loadModel('user')->getPairs('noletter');
        $this->view->param       = $param;
        $this->view->projectID   = $projectID;
        $this->view->project     = $project;
        $this->view->moduleID    = $moduleID;
        $this->view->moduleTree  = $this->tree->getTreeMenu($projectID, $viewType = 'task', $startModuleID = 0, array('treeModel', 'createTaskLink'));
        $this->view->projectTree = $this->project->tree();

        $this->display();
    }
}
