<script>
$('#featurebar').hide();
</script>
