<script>
$('#allTab').before($('#bymoduleTab'));
$('#byprojectTab').hide();
$('#burnTab').hide();
$('#allTab').appendTo($('#groupTab'));
</script>
