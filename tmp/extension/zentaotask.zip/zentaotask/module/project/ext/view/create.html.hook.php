<script language='Javascript'>
$('#productsBox').parent().hide();
$('#type').parent().parent().html('<input name="type" style="display:none" value="waterfall">');
</script>
