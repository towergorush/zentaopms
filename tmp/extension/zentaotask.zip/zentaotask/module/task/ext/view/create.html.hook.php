<script language='Javascript'>
$('div .f-right a:last-child').hide();
$('#story').parent().parent().hide();
$('#name').next('.button-c').hide();
$('input:checked').next('input').attr('checked', true);
$('input:checked').parent().parent().hide();
$('#preview').parent().parent().hide();
</script>
