<script>
$('#storyTab').hide();
$('#testTab').hide();
$('#todoTab').hide();
$('#bugTab').hide();
</script>
