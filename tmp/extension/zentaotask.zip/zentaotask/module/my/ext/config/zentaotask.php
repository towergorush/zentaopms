<?php
$config->my->dynamicCounts = 16; 
