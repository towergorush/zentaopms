<?php
$lang->my->assignedToMeTask = 'Assgined to me';
$lang->my->openedByMeTask   = 'Opened by me';
