<?php
$lang->my->assignedToMeTask = '指派给我的任务';
$lang->my->openedByMeTask   = '由我创建的任务';
