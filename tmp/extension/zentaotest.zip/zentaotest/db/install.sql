DELETE FROM `zt_groupPriv` WHERE `module` = 'product' AND `method` = 'build';
INSERT INTO `zt_groupPriv` (`group`, `module`, `method`) VALUES
(1,  'product', 'build'),
(2,  'product', 'build'),
(3,  'product', 'build'),
(4,  'product', 'build'),
(5,  'product', 'build'),
(6,  'product', 'build'),
(7,  'product', 'build'),
(8,  'product', 'build'),
(9,  'product', 'build'),
(10, 'product', 'build');
