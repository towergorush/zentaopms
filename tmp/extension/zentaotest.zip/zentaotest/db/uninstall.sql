DELETE FROM `zt_groupPriv` WHERE `module` = 'product' AND `method` = 'build';
