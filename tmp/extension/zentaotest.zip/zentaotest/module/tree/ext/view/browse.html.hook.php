<script language='Javascript'>
$('.button-c').hide();
</script>
