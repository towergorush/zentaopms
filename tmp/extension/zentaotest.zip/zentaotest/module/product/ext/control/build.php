<?php
/**
 * The control file of project module of ZenTaoMS.
 *
 * ZenTaoMS is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * ZenTaoMS is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with ZenTaoMS.  If not, see <http://www.gnu.org/licenses/>.  
 *
 * @copyright   Copyright 2009-2010 青岛易软天创网络科技有限公司(www.cnezsoft.com)
 * @author      Chunsheng Wang <chunsheng@cnezsoft.com>
 * @package     project
 * @version     $Id: control.php 925 2010-07-06 02:38:04Z yuren_@126.com $
 * @link        http://www.zentaoms.com
 */
class product extends control
{
    /* 浏览某一个产品的build。*/
    public function build($productID = 0)
    {
        $this->app->loadLang('build');
        $this->session->set('productList', $this->app->getURI(true));

        /* 获取所有的产品列表。如果还没有产品，则跳转到产品的添加页面。*/
        $this->products = $this->product->getPairs();
        if(empty($this->products) and strpos('create|view', $this->methodName) === false) $this->locate($this->createLink('product', 'create'));

        /* 获得当前的产品信息。*/
        $productID = $this->product->saveState($productID, $this->products);
        $product   = $this->product->getById($productID);
        $this->product->setMenu($this->products, $productID);

        /* 设置菜单。*/
        $this->session->set('buildList', $this->app->getURI(true));

        /* 设定header和position信息。*/
        $this->view->title      = $product->name . $this->lang->colon . $this->lang->product->build;
        $this->view->position[] = $this->lang->product->build;

        /* 查找build列表。*/
        $this->view->products = $this->products;
        $this->view->product  = $product;
        $this->view->builds   = $this->dao->select('*')->from(TABLE_BUILD)->where('product')->eq($productID)->andWhere('deleted')->eq(0)->fetchAll();

        $this->display();
    }


}
