<script language='Javascript'>
$('fieldset').next().hide();
</script>
