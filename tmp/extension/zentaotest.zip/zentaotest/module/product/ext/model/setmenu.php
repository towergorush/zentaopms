public function setMenu($products, $productID, $extra = '')
{
    /* 获得当前的模块和方法，传递给switchProduct方法，供页面跳转使用。*/
    $currentModule = $this->app->getModuleName();
    $currentMethod = $this->app->getMethodName();

    $selectHtml = html::select('productID', $products, $productID, "onchange=\"switchProduct(this.value, '$currentModule', '$currentMethod', '$extra');\"");
    common::setMenuVars($this->lang->product->menu, 'list',   $selectHtml . $this->lang->arrow);
    foreach($this->lang->product->menu as $key => $menu)
    {
        if($key == 'list')
        {
            common::setMenuVars($this->lang->product->menu, 'list', $productID);
        }
        else
        {
            common::setMenuVars($this->lang->product->menu, $key, $productID);
        }
    }
}
