<?php
/**
 * The common simplified chinese file of ZenTaoMS.
 *
 * This file should be UTF-8 encoded.
 *
 * ZenTaoMS is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.

 * ZenTaoMS is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with ZenTaoMS.  If not, see <http://www.gnu.org/licenses/>.
 *
 * @copyright   Copyright 2009-2010 青岛易软天创网络科技有限公司(www.cnezsoft.com)
 * @author      Chunsheng Wang <chunsheng@cnezsoft.com>
 * @package     ZenTaoMS
 * @version     $Id: zh-cn.php 824 2010-05-02 15:32:06Z wwccss $
 * @link        http://www.zentaoms.com
 */

/* delete menu of project and qa */
unset($lang->menu->project);
unset($lang->menu->qa);
unset($lang->menu->report);

unset($lang->menuOrder[15]);
unset($lang->menuOrder[20]);
unset($lang->menuOrder[30]);

/* adjust submenu of my module */
unset($lang->my->menu->task);
unset($lang->my->menu->myProject);
unset($lang->my->menu->story);

/* delete submenu of project module */
unset($lang->project->menu);
unset($lang->project->menuOrder);

/* add menu of bug,testcase and testtask */
$lang->menu->bug      = 'Bug|bug|index';
$lang->menu->testcase = 'Testcase|testcase|index';
$lang->menu->testtask = 'Testtask|testtask|index';

$lang->menuOrder[6] = 'bug';
$lang->menuOrder[7] = 'testcase';
$lang->menuOrder[8] = 'testtask';

/* adjust submenu of bug module */
$lang->bug->menu      = new stdclass();

$lang->bug->menu->product  = '%s';
$lang->bug->menu->browse   = array('link' => 'Browse|bug|browse|productID=%s', 'alias' => 'viewedit,resolve,close,activate,report', 'subModule' => 'tree');
$lang->bug->menu->create   = array('link' => 'Create|bug|create|productID=%s');

$lang->bug->menuOrder[5]  = 'product';
$lang->bug->menuOrder[10] = 'browse';
$lang->bug->menuOrder[15] = 'create';

/* adjust submenu of testcase module */
$lang->testcase->menu      = new stdclass();

$lang->testcase->menu->product  = '%s';
$lang->testcase->menu->browse   = array('link' => 'Browse|testcase|browse|productID=%s', 'alias' => 'viewedit,resolve,close,activate,report', 'subModule' => 'tree');
$lang->testcase->menu->create   = array('link' => 'Create|testcase|create|productID=%s');

$lang->testcase->menuOrder[5]  = 'product';
$lang->testcase->menuOrder[10] = 'browse';
$lang->testcase->menuOrder[15] = 'create';

/* adjust submenu of testtask module */
$lang->testtask->menu      = new stdclass();

$lang->testtask->menu->product  = '%s';
$lang->testtask->menu->browse   = array('link' => 'Browse|testtask|browse|productID=%s', 'alias' => 'viewedit,resolve,close,activate,report', 'subModule' => 'tree');
$lang->testtask->menu->create   = array('link' => 'Create|testtask|create|productID=%s');

$lang->testtask->menuOrder[5]  = 'product';
$lang->testtask->menuOrder[10] = 'browse';
$lang->testtask->menuOrder[15] = 'create';

/* adjust submenu of product module */
unset($lang->product->menu->story);
unset($lang->product->menu->project);
unset($lang->product->menu->release);
unset($lang->product->menu->dynamic);
unset($lang->product->menu->plan);
unset($lang->product->menu->roadmap);
unset($lang->product->menu->doc);
unset($lang->product->menu->module);

$lang->product->menu->build = array('link' => 'Build|product|build', 'subModule' => 'build');

$lang->product->menuOrder[5]  = 'build';
$lang->product->menuOrder[10] = 'view';
$lang->product->menuOrder[15] = 'order';

$lang->build->menu      = $lang->product->menu;
$lang->build->menuOrder = $lang->product->menuOrder;

/* adjust menugroup */
$lang->menugroup->bug      = 'bug';
$lang->menugroup->testcase = 'testcase';
$lang->menugroup->testtask = 'testtask';
