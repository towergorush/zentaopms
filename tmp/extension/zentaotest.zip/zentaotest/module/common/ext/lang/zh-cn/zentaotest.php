<?php
/**
 * The common simplified chinese file of ZenTaoMS.
 *
 * This file should be UTF-8 encoded.
 *
 * ZenTaoMS is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.

 * ZenTaoMS is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with ZenTaoMS.  If not, see <http://www.gnu.org/licenses/>.
 *
 * @copyright   Copyright 2009-2010 青岛易软天创网络科技有限公司(www.cnezsoft.com)
 * @author      Chunsheng Wang <chunsheng@cnezsoft.com>
 * @package     ZenTaoMS
 * @version     $Id: zh-cn.php 824 2010-05-02 15:32:06Z wwccss $
 * @link        http://www.zentaoms.com
 */

/* 删掉项目和测试视图 */
unset($lang->menu->project);
unset($lang->menu->qa);
unset($lang->menu->report);

unset($lang->menuOrder[15]);
unset($lang->menuOrder[20]);
unset($lang->menuOrder[30]);

/* 重命名产品视图 */
$lang->menu->product = '产品|product|index';

/* 调整我的地盘的二级菜单 */
unset($lang->my->menu->task);
unset($lang->my->menu->myProject);
unset($lang->my->menu->story);
unset($lang->my->menu->todo);

/* 删除项目视图的二级菜单 */
unset($lang->project->menu);
unset($lang->project->menuOrder);

/* 增加缺陷管理、用例管理和测试任务视图 */
$lang->menu->bug      = 'Bug|bug|index';
$lang->menu->testcase = '用例|testcase|index';
$lang->menu->testtask = '测试|testtask|index';

$lang->menuOrder[6] = 'bug';
$lang->menuOrder[7] = 'testcase';
$lang->menuOrder[8] = 'testtask';

/* 调整缺陷管理的二级菜单 */
$lang->bug->menu      = new stdclass();

$lang->bug->menu->product  = '%s';
$lang->bug->menu->browse   = array('link' => '浏览Bug|bug|browse|productID=%s', 'alias' => 'viewedit,resolve,close,activate,report', 'subModule' => 'tree');
$lang->bug->menu->create   = array('link' => '提Bug|bug|create|productID=%s');

$lang->bug->menuOrder[5]  = 'product';
$lang->bug->menuOrder[10] = 'browse';
$lang->bug->menuOrder[15] = 'create';

/* 调整用例管理的二级菜单 */
$lang->testcase->menu      = new stdclass();

$lang->testcase->menu->product  = '%s';
$lang->testcase->menu->browse   = array('link' => '浏览用例|testcase|browse|productID=%s', 'alias' => 'viewedit,resolve,close,activate,report', 'subModule' => 'tree');
$lang->testcase->menu->create   = array('link' => '创建用例|testcase|create|productID=%s');

$lang->testcase->menuOrder[5]  = 'product';
$lang->testcase->menuOrder[10] = 'browse';
$lang->testcase->menuOrder[15] = 'create';

/* 调整测试任务的二级菜单 */
$lang->testtask->menu      = new stdclass();

$lang->testtask->menu->product  = '%s';
$lang->testtask->menu->browse   = array('link' => '浏览任务|testtask|browse|productID=%s', 'alias' => 'viewedit,resolve,close,activate,report', 'subModule' => 'tree');
$lang->testtask->menu->create   = array('link' => '创建任务|testtask|create|productID=%s');

$lang->testtask->menuOrder[5]  = 'product';
$lang->testtask->menuOrder[10] = 'browse';
$lang->testtask->menuOrder[15] = 'create';

/* 调整产品视图的二级菜单 */
unset($lang->product->menu->story);
unset($lang->product->menu->project);
unset($lang->product->menu->release);
unset($lang->product->menu->dynamic);
unset($lang->product->menu->plan);
unset($lang->product->menu->roadmap);
unset($lang->product->menu->doc);
unset($lang->product->menu->module);

$lang->product->menu->build = array('link' => '版本|product|build', 'subModule' => 'build');

$lang->product->menuOrder[5]  = 'build';
$lang->product->menuOrder[10] = 'view';
$lang->product->menuOrder[15] = 'order';

$lang->build->menu      = $lang->product->menu;
$lang->build->menuOrder = $lang->product->menuOrder;

/* 调整菜单分组 */
$lang->menugroup->bug      = 'bug';
$lang->menugroup->testcase = 'testcase';
$lang->menugroup->testtask = 'testtask';
