<script>
$('#todoTab').hide();
$('#taskTab').hide();
$('#projectTab').hide();
</script>
