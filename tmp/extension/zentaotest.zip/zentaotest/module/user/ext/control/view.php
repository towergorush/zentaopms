<?php
class user extends control
{
    public function view($account)
    {
        $this->locate($this->createLink('user', 'bug', "account=$account")); 
    }
}
