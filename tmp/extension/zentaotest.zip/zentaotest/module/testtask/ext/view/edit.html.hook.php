<script language='Javascript'>
$("#project").parent().parent().remove();
</script>
