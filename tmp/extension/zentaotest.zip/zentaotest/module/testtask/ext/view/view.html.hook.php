<script language='Javascript'>
//$("tr>th:eq(2)").remove();
//$("tr>td:eq(2)").remove();
</script>
