<?php
/**
 * The group module zh-cn file of ZenTaoMS.
 *
 * ZenTaoMS is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * ZenTaoMS is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with ZenTaoMS.  If not, see <http://www.gnu.org/licenses/>.  
 *
 * @copyright   Copyright 2009-2010 青岛易软天创网络科技有限公司(www.cnezsoft.com)
 * @author      Chunsheng Wang <chunsheng@cnezsoft.com>
 * @package     group
 * @version     $Id: zh-cn.php 918 2010-07-06 01:51:26Z wwccss $
 * @link        http://www.zentaoms.com
 */
unset($lang->resource->todo);
unset($lang->resource->project);
unset($lang->resource->story);
unset($lang->resource->productplan);
unset($lang->resource->release);
unset($lang->resource->task);
unset($lang->resource->qa);
unset($lang->resource->report);
unset($lang->moduleOrder[10]);
unset($lang->moduleOrder[20]);
unset($lang->moduleOrder[25]);
unset($lang->moduleOrder[30]);
unset($lang->moduleOrder[35]);
unset($lang->moduleOrder[40]);
unset($lang->moduleOrder[50]);
unset($lang->moduleOrder[75]);

unset($lang->resource->my->todo);
unset($lang->resource->my->task);
unset($lang->resource->my->story);
unset($lang->resource->my->project);
unset($lang->my->methodOrder[5]);
unset($lang->my->methodOrder[10]);
unset($lang->my->methodOrder[30]);
unset($lang->my->methodOrder[35]);


unset($lang->resource->product->browse);
unset($lang->resource->product->roadmap);
unset($lang->resource->product->dynamic);
unset($lang->resource->product->project);
unset($lang->resource->product->ajaxGetProjects);
unset($lang->resource->product->ajaxGetPlans);
unset($lang->product->methodOrder[5]);
unset($lang->product->methodOrder[35]);
unset($lang->product->methodOrder[45]);
unset($lang->product->methodOrder[50]);
unset($lang->product->methodOrder[55]);
unset($lang->product->methodOrder[60]);

unset($lang->resource->build->ajaxGetProjectBuilds);
unset($lang->build->methodOrder[30]);

unset($lang->resource->bug->confirmStoryChange);
unset($lang->bug->methodOrder[60]);

unset($lang->resource->testcase->confirmStoryChange);
unset($lang->testcase->methodOrder[40]);

$lang->resource->product->build = 'build';
$lang->product->methodOrder[5]  = 'build';
