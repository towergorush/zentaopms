<?php
$config->my->bugCounts     = 20; 
$config->my->dynamicCounts = 18; 
