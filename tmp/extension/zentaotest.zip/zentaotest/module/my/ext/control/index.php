<?php
/**
 * The control file of dashboard module of ZenTaoPMS.
 *
 * @copyright   Copyright 2009-2011 青岛易软天创网络科技有限公司 (QingDao Nature Easy Soft Network Technology Co,LTD www.cnezsoft.com)
 * @license     LGPL (http://www.gnu.org/licenses/lgpl.html)
 * @author      Chunsheng Wang <chunsheng@cnezsoft.com>
 * @package     dashboard
 * @version     $Id: control.php 1961 2011-06-30 08:04:02Z wwccss $
 * @link        http://www.zentao.net
 */
class my extends control
{
    /**
     * Construct function.
     * 
     * @access public
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
        $this->my->setMenu();
    }

    /**
     * Index page, goto todo.
     * 
     * @access public
     * @return void
     */
    public function index()
    {
        $account = $this->app->user->account;

        /* Set the dynamic pager. */
        $this->app->loadClass('pager', true);
        $pager = new pager(0, $this->config->my->dynamicCounts);

        $this->view->actions          = $this->loadModel('action')->getDynamic('all', 'all', 'id_desc', $pager);
        $this->view->todos            = $this->loadModel('todo')->getList('today', $account, 'wait, doing', $this->config->my->todoCounts);
        $this->view->bugs             = $this->loadModel('bug')->getUserBugPairs($account, false, $this->config->my->bugCounts);
        $this->view->assignToMeBugs   = $this->loadModel('bug')->getAssignToMeBugs($account, $this->config->my->bugCounts);
        $this->view->openedByMeBugs   = $this->loadModel('bug')->getOpenedByMeBugs($account, $this->config->my->bugCounts);
        $this->view->latestBugs       = $this->loadModel('bug')->getLatestBugs($this->config->my->bugCounts);
        $this->view->unresolvedBugs   = $this->loadModel('bug')->getUnresolvedBugs($this->config->my->bugCounts);
        $this->view->users            = $this->loadModel('user')->getPairs('noletter|withguest');
        $this->view->title            = $this->lang->my->common;

        $this->display();
    }
}
