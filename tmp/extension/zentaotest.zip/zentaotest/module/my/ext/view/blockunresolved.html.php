<div class='block linkbox2'>
<table class='table-1 fixed colored'>
  <caption>
    <div class='f-left'><span class='icon-bug'></span> <?php echo $lang->my->bugs->unresolved;?></div>
  </caption>
  <?php 
  foreach($unresolvedBugs as $bugID => $bugTitle)
  {
      echo "<tr><td class='nobr'>" . "#$bugID " . html::a($this->createLink('bug', 'view', "id=$bugID"), $bugTitle) . "</td><td width='5'></td></tr>";
  }
  ?>
</table>
</div>
