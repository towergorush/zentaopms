<div class='block linkbox2'>
<table class='table-1 fixed colored'>
  <caption>
    <div class='f-left'><span class='icon-bug'></span> <?php echo $lang->my->bugs->latest;?></div>
  </caption>
  <?php 
  foreach($latestBugs as $bugID => $bugTitle)
  {
      echo "<tr><td class='nobr'>" . "#$bugID " . html::a($this->createLink('bug', 'view', "id=$bugID"), $bugTitle) . "</td><td width='5'></td></tr>";
  }
  ?>
</table>
</div>
