<?php
$lang->my->bugs = new stdclass();
$lang->my->bugs->assignToMe = '指派给我的Bug';
$lang->my->bugs->openedByMe = '由我创建的Bug';
$lang->my->bugs->latest     = '最新Bug';
$lang->my->bugs->unresolved = '未解决的Bug';
