<?php
$lang->my->bugs = new stdclass();
$lang->my->bugs->assignToMe = 'Assign to me';
$lang->my->bugs->openedByMe = 'Opened by me';
$lang->my->bugs->latest     = 'Latest';
$lang->my->bugs->unresolved = 'Unresolved';
