<script language='Javascript'>
$('fieldset:eq(5)').hide();
$('.icon-green-story-toStory').parent().hide();
</script>
