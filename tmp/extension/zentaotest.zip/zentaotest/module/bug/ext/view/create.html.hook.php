<style>#module{width:200px}</style>
<script language='Javascript'>
$('#projectIdBox').parent().parent().hide();
$('#taskIdBox').parent().parent().hide();
$('#storyIdBox').parent().parent().hide();
</script>
