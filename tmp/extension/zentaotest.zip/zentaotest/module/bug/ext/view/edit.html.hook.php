<script language='Javascript'>
$('#projectIdBox').parent().hide();
</script>
