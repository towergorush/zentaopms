<?php
class zentaotestBug extends bugModel
{
    public function getAssignToMeBugs($account, $limit = 0)
    {
        $bugs = array();
        $stmt = $this->dao->select('id, title')
            ->from(TABLE_BUG)
            ->where('assignedTo')->eq($account)
            ->andWhere('deleted')->eq(0)
            ->orderBy('id desc')
            ->beginIF($limit > 0)->limit($limit)->fi()
            ->query();
        while($bug = $stmt->fetch())
        {
            $bugs[$bug->id] = $bug->title;
        }
        return $bugs;
    }

    public function getOpenedByMeBugs($account, $limit = 0)
    {
        $bugs = array();
        $stmt = $this->dao->select('id, title')
            ->from(TABLE_BUG)
            ->where('openedBy')->eq($account)
            ->andWhere('deleted')->eq(0)
            ->orderBy('id desc')
            ->beginIF($limit > 0)->limit($limit)->fi()
            ->query();
        while($bug = $stmt->fetch())
        {
            $bugs[$bug->id] = $bug->title;
        }
        return $bugs;
    }

    public function getLatestBugs($limit = 0)
    {
        $bugs = array();
        $stmt = $this->dao->select('id, title')
            ->from(TABLE_BUG)
            ->where('deleted')->eq(0)
            ->orderBy('id desc')
            ->beginIF($limit > 0)->limit($limit)->fi()
            ->query();
        while($bug = $stmt->fetch())
        {
            $bugs[$bug->id] = $bug->title;
        }
        return $bugs;
    }

    public function getUnresolvedBugs($limit = 0)
    {
        $bugs = array();
        $stmt = $this->dao->select('id, title')
            ->from(TABLE_BUG)
            ->where('status')->eq('active')
            ->andWhere('deleted')->eq(0)
            ->orderBy('id desc')
            ->beginIF($limit > 0)->limit($limit)->fi()
            ->query();
        while($bug = $stmt->fetch())
        {
            $bugs[$bug->id] = $bug->title;
        }
        return $bugs;
    }
}
