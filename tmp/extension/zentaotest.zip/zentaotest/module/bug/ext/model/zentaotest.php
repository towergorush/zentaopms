<?php
public function getAssignToMeBugs($account, $limit = 0)
{
    return $this->loadExtension('zentaotest')->getAssignToMeBugs($account, $limit);
}

public function getOpenedByMeBugs($account, $limit = 0)
{
    return $this->loadExtension('zentaotest')->getOpenedByMeBugs($account, $limit);
}

public function getLatestBugs($limit = 0)
{
    return $this->loadExtension('zentaotest')->getLatestBugs($limit);
}

public function getUnresolvedBugs($limit = 0)
{
    return $this->loadExtension('zentaotest')->getUnresolvedBugs($limit);
}
