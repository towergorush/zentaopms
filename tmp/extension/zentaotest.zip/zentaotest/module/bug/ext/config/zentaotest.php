<?php
unset($config->bug->search['fields']['project']);
unset($config->bug->search['fields']['toTask']);
unset($config->bug->search['fields']['toStory']);

$config->bug->list->allFields = 'id, module, story,
    title, keywords, severity, pri, type, os, browser, hardware,
    found, steps, status, activatedCount, confirmed, mailto,
    openedBy, openedDate, openedBuild,
    assignedTo, assignedDate,
    resolvedBy, resolution, resolvedBuild, resolvedDate,
    closedBy, closedDate,
    duplicateBug, linkBug,
    case,
    lastEditedBy,
    lastEditedDate';

