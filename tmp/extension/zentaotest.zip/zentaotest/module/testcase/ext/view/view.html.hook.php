<script language='Javascript'>
$('.nofixed').remove();
</script>
