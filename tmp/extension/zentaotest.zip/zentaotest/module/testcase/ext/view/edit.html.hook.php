<script language='Javascript'>$('#storyIdBox').parent().parent().hide();</script>
