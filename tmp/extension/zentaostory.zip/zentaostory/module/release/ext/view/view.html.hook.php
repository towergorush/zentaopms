<script>
$('#actionbox').next().next().next().hide();
</script>
