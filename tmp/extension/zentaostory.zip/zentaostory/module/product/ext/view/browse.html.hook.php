<script>
    $(".icon-green-testcase-createCase").hide();
</script>
