<?php
/**
 * The common simplified chinese file of ZenTaoMS.
 *
 * This file should be UTF-8 encoded.
 *
 * ZenTaoMS is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.

 * ZenTaoMS is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with ZenTaoMS.  If not, see <http://www.gnu.org/licenses/>.
 *
 * @copyright   Copyright 2009-2010 青岛易软天创网络科技有限公司(www.cnezsoft.com)
 * @author      Chunsheng Wang <chunsheng@cnezsoft.com>
 * @package     ZenTaoMS
 * @version     $Id: zh-cn.php 824 2010-05-02 15:32:06Z wwccss $
 * @link        http://www.zentaoms.com
 */

/* 删掉产品、统计和测试视图 */
unset($lang->menu->project);
unset($lang->menu->report);
unset($lang->menu->qa);

unset($lang->menuOrder[15]);
unset($lang->menuOrder[20]);
unset($lang->menuOrder[30]);

/* 调整我的地盘的二级菜单 */
unset($lang->my->menu->bug);
unset($lang->my->menu->todo);
unset($lang->my->menu->testtask);
unset($lang->my->menu->task);
unset($lang->my->menu->myProject);

/* 调整产品视图的二级菜单 */
unset($lang->product->menu->project);

/* 重命名产品视图、文档视图和组织视图*/
$lang->menu->product = '产品|product|index';
$lang->menu->doc     = '文档|doc|index';
$lang->menu->company = '组织|company|index';

