<script>
$('#testTab').hide();
$('#todoTab').hide();
$('#taskTab').hide();
$('#bugTab').hide();
$('#projectTab').hide();
</script>
