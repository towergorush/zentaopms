<?php
/**
 * The control file of dashboard module of ZenTaoPMS.
 *
 * @copyright   Copyright 2009-2011 青岛易软天创网络科技有限公司 (QingDao Nature Easy Soft Network Technology Co,LTD www.cnezsoft.com)
 * @license     LGPL (http://www.gnu.org/licenses/lgpl.html)
 * @author      Chunsheng Wang <chunsheng@cnezsoft.com>
 * @package     dashboard
 * @version     $Id: control.php 1961 2011-06-30 08:04:02Z wwccss $
 * @link        http://www.zentao.net
 */
class my extends control
{
    /**
     * Construct function.
     * 
     * @access public
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
        $this->my->setMenu();
    }

    /**
     * Index page, goto todo.
     * 
     * @access public
     * @return void
     */
    public function index()
    {
        $account = $this->app->user->account;

        /* Set the dynamic pager. */
        $this->app->loadClass('pager', true);
        $pager = new pager(0, $this->config->my->dynamicCounts);

        $productStats = $this->loadModel('product')->getStats();

        $this->view->productStats        = $productStats;
        $this->view->actions             = $this->loadModel('action')->getDynamic('all', 'all', 'id_desc', $pager);
        $this->view->assignedToMeStories = $this->loadModel('story')->getUserStories($account, 'assignedTo', 'id_desc', null, $this->config->my->taskCounts);
        $this->view->openedByMeStories   = $this->loadModel('story')->getUserStories($account, 'openedBy', 'id_desc', null, $this->config->my->taskCounts);
        $this->view->users               = $this->loadModel('user')->getPairs('noletter|withguest');
        $this->view->title               = $this->lang->my->common;

        $this->display();
    }
}
