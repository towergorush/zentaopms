<?php
$lang->my->assignedToMeStory = '指派给我';
$lang->my->openedByMeStory   = '由我创建';
