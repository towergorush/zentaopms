<?php
$lang->my->assignedToMeStory = 'Assgined to me';
$lang->my->openedByMeStory   = 'Opened by me';
