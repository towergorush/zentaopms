<script>
    $(".icon-green-testcase-createCase").parent().hide();
    $('.side fieldset:eq(2)').hide();
    $('.side fieldset:eq(3)').hide();
    $('.side fieldset:eq(4)').hide();
    $('.side fieldset:eq(7)').hide();
</script>
