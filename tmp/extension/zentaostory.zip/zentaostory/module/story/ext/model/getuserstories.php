<?php
/**
 * Get stories of a user.
 *
 * @param  string $account
 * @param  string $type         the query type
 * @param  string $orderBy
 * @param  object $pager
 * @access public
 * @return array
 */
public function getUserStories($account, $type = 'assignedto', $orderBy = 'id_desc', $pager = null, $limit = 0)
{
    $type = strtolower($type);
    $stories = $this->dao->select('t1.*, t2.title as planTitle, t3.name as productTitle')
        ->from(TABLE_STORY)->alias('t1')
        ->leftJoin(TABLE_PRODUCTPLAN)->alias('t2')->on('t1.plan = t2.id')
        ->leftJoin(TABLE_PRODUCT)->alias('t3')->on('t1.product = t3.id')
        ->where('t1.deleted')->eq(0)
        ->beginIF($type == 'assignedto')->andWhere('assignedTo')->eq($this->app->user->account)->fi()
        ->beginIF($type == 'openedby')->andWhere('openedby')->eq($this->app->user->account)->fi()
        ->beginIF($type == 'reviewedby')->andWhere('reviewedby')->like('%' . $this->app->user->account . '%')->fi()
        ->beginIF($type == 'closedby')->andWhere('closedby')->eq($this->app->user->account)->fi()
        ->orderBy($orderBy)->page($pager)
        ->beginIF($limit > 0)->limit($limit)->fi()
        ->fetchAll();

    $this->loadModel('common')->saveQueryCondition($this->dao->get(), 'story');

    return $stories;
}
