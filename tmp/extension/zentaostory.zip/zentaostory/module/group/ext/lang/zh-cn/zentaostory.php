<?php
/**
 * The group module zh-cn file of ZenTaoMS.
 *
 * ZenTaoMS is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * ZenTaoMS is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with ZenTaoMS.  If not, see <http://www.gnu.org/licenses/>.  
 *
 * @copyright   Copyright 2009-2010 青岛易软天创网络科技有限公司(www.cnezsoft.com)
 * @author      Chunsheng Wang <chunsheng@cnezsoft.com>
 * @package     group
 * @version     $Id: zh-cn.php 918 2010-07-06 01:51:26Z wwccss $
 * @link        http://www.zentaoms.com
 */
unset($lang->resource->todo);
unset($lang->moduleOrder[10]);
unset($lang->resource->project);
unset($lang->moduleOrder[35]);
unset($lang->resource->task);
unset($lang->moduleOrder[40]);
unset($lang->resource->build);
unset($lang->moduleOrder[45]);
unset($lang->resource->qa);
unset($lang->moduleOrder[50]);
unset($lang->resource->bug);
unset($lang->moduleOrder[55]);
unset($lang->resource->testcase);
unset($lang->moduleOrder[60]);
unset($lang->resource->testtask);
unset($lang->moduleOrder[65]);
unset($lang->resource->report);
unset($lang->moduleOrder[75]);

unset($lang->resource->my->bug);
unset($lang->resource->my->task);
unset($lang->resource->my->project);
unset($lang->resource->my->todo);
unset($lang->resource->my->testTask);
unset($lang->resource->my->testCase);

unset($lang->resource->product->project);

unset($lang->resource->story->tasks);
