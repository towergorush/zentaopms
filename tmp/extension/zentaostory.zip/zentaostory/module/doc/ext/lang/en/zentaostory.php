<?php
unset($lang->doc->systemLibs['project']);
