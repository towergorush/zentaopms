<?php
$flowValue = $this->loadModel('setting')->getItem('company=0&owner=system&module=common&section=global&key=flow');
if($flowValue == 'onlyStory') $this->setting->setItem('system.common.global.flow', 'full');
